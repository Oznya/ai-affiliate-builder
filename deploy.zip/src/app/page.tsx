'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import StarryBackground from '@/components/StarryBackground'
import { 
  Zap, 
  Link as LinkIcon, 
  Tag, 
  Sparkles, 
  ArrowRight, 
  ExternalLink, 
  Trash2,
  Loader2,
  Globe,
  Rocket,
  CheckCircle,
  Copy,
  Crown,
  Star,
  Image as ImageIcon,
  RefreshCw,
  Palette,
  Layout,
  CreditCard,
  X
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Site {
  id: string
  name: string
  slug: string
  headline: string
  subheadline: string
  createdAt: string
  niche: string | null
  template: string
  imageUrl: string | null
  customImageUrl: string | null
}

const TEMPLATES = [
  { id: 'modern', name: 'Moderne', description: 'Design épuré avec gradients', icon: '✨' },
  { id: 'classic', name: 'Classique', description: 'Style professionnel traditionnel', icon: '👔' },
  { id: 'minimal', name: 'Minimal', description: 'Simple et efficace', icon: '◻️' },
  { id: 'dark', name: 'Dark Pro', description: 'Ambiance sombre premium', icon: '🌙' },
]

const PLANS = [
  {
    id: 'free',
    name: 'Gratuit',
    price: 0,
    priceYearly: 0,
    features: ['3 sites', 'Template Moderne', 'Génération IA basique'],
    limit: 3,
    popular: false
  },
  {
    id: 'starter',
    name: 'Starter',
    price: 19,
    priceYearly: 190,
    features: ['10 sites', '4 Templates', 'Génération IA avancée', 'Support prioritaire'],
    limit: 10,
    popular: false
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 49,
    priceYearly: 490,
    features: ['Sites illimités', '4 Templates', 'Images personnalisées', 'Analytics', 'Support VIP'],
    limit: -1,
    popular: true
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 199,
    priceYearly: 1990,
    features: ['Tout illimité', 'Marque blanche', 'API Access', 'Manager dédié'],
    limit: -1,
    popular: false
  }
]

export default function Home() {
  const [productUrl, setProductUrl] = useState('')
  const [affiliateUrl, setAffiliateUrl] = useState('')
  const [niche, setNiche] = useState('')
  const [customName, setCustomName] = useState('')
  const [selectedTemplate, setSelectedTemplate] = useState('modern')
  const [isGenerating, setIsGenerating] = useState(false)
  const [sites, setSites] = useState<Site[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showPricing, setShowPricing] = useState(false)
  const [editingImage, setEditingImage] = useState<string | null>(null)
  const { toast } = useToast()

  // Simulated user state (in production, this would come from auth)
  const [userPlan] = useState('free')
  const [sitesCreated] = useState(0)

  useEffect(() => {
    fetchSites()
  }, [])

  const fetchSites = async () => {
    try {
      const response = await fetch('/api/sites')
      const data = await response.json()
      setSites(data.sites || [])
    } catch (error) {
      console.error('Error fetching sites:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleGenerate = async () => {
    if (!productUrl) {
      toast({
        title: 'Erreur',
        description: 'Veuillez entrer une URL de produit',
        variant: 'destructive'
      })
      return
    }

    // Check plan limits
    const currentPlan = PLANS.find(p => p.id === userPlan) || PLANS[0]
    if (currentPlan.limit > 0 && sites.length >= currentPlan.limit) {
      toast({
        title: 'Limite atteinte',
        description: `Vous avez atteint la limite de ${currentPlan.limit} sites. Passez à un plan supérieur!`,
        variant: 'destructive'
      })
      setShowPricing(true)
      return
    }

    setIsGenerating(true)
    
    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productUrl,
          affiliateUrl: affiliateUrl || productUrl,
          niche: niche || undefined,
          customName: customName || undefined,
          template: selectedTemplate
        })
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: 'Site généré avec succès!',
          description: 'Votre page affiliée est prête.',
        })
        setProductUrl('')
        setAffiliateUrl('')
        setNiche('')
        setCustomName('')
        fetchSites()
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      toast({
        title: 'Erreur',
        description: 'Impossible de générer le site. Veuillez réessayer.',
        variant: 'destructive'
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/sites?id=${id}`, { method: 'DELETE' })
      setSites(sites.filter(s => s.id !== id))
      toast({
        title: 'Site supprimé',
        description: 'Le site a été supprimé avec succès.',
      })
    } catch (error) {
      toast({
        title: 'Erreur',
        description: 'Impossible de supprimer le site.',
        variant: 'destructive'
      })
    }
  }

  const handleRegenerateImage = async (siteId: string) => {
    toast({
      title: 'Régénération...',
      description: 'Nouvelle image en cours de génération.',
    })
    // In production, this would call an API to regenerate the image
  }

  const copyToClipboard = (slug: string) => {
    const url = `${window.location.origin}/site/${slug}`
    navigator.clipboard.writeText(url)
    toast({
      title: 'URL copiée!',
      description: 'L\'URL a été copiée dans le presse-papiers.',
    })
  }

  return (
    <div className="min-h-screen relative">
      {/* Animated Starry Background with Canvas */}
      <StarryBackground />

      {/* Header */}
      <header className="border-b border-indigo-500/20 bg-slate-900/30 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <Zap className="h-7 w-7 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">AI Affiliate Builder</h1>
              <p className="text-xs text-indigo-300">Générateur de sites en 1 clic</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-0 pulse-glow">
              <Sparkles className="h-3 w-3 mr-1" />
              Powered by AI
            </Badge>
            <Button 
              variant="outline" 
              className="border-indigo-500/50 text-indigo-300 hover:bg-indigo-500/20"
              onClick={() => setShowPricing(true)}
            >
              <Crown className="h-4 w-4 mr-2" />
              Passer Pro
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12 relative">
        {/* Hero Section */}
        <div className="text-center mb-12 animate-fade-in">
          <Badge className="mb-4 bg-gradient-to-r from-violet-500/20 to-purple-500/20 text-violet-300 border-violet-500/30">
            Nouveau
          </Badge>
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Générez votre site affilié en{' '}
            <span className="gradient-text">60 secondes</span>
          </h2>
          <p className="text-xl text-indigo-200/80 max-w-3xl mx-auto">
            Collez l&apos;URL de votre produit et laissez l&apos;IA créer une page de review optimisée avec contenu, images et design professionnel.
          </p>
          
          {/* Stats */}
          <div className="flex justify-center gap-8 mt-8">
            <div className="text-center">
              <p className="text-3xl font-bold gradient-text">{sites.length}</p>
              <p className="text-sm text-indigo-300">Sites créés</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold gradient-text">4</p>
              <p className="text-sm text-indigo-300">Templates</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold gradient-text">100%</p>
              <p className="text-sm text-indigo-300">IA Généré</p>
            </div>
          </div>
        </div>

        {/* Main Generator Card */}
        <Card className="glass-card mb-12 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Rocket className="h-5 w-5 text-indigo-400" />
              Créer un nouveau site
            </CardTitle>
            <CardDescription className="text-indigo-200/60">
              Entrez les informations de votre produit pour générer une page affiliée optimisée
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="productUrl" className="text-indigo-100 flex items-center gap-2">
                  <LinkIcon className="h-4 w-4 text-indigo-400" />
                  URL du produit *
                </Label>
                <Input
                  id="productUrl"
                  type="url"
                  placeholder="https://amazon.com/product/..."
                  value={productUrl}
                  onChange={(e) => setProductUrl(e.target.value)}
                  className="bg-slate-900/50 border-indigo-500/30 text-white placeholder:text-slate-500 focus:border-indigo-400 focus:ring-indigo-400/20"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="affiliateUrl" className="text-indigo-100 flex items-center gap-2">
                  <LinkIcon className="h-4 w-4 text-purple-400" />
                  URL affiliée (optionnel)
                </Label>
                <Input
                  id="affiliateUrl"
                  type="url"
                  placeholder="https://affiliatenetwork.com/track/..."
                  value={affiliateUrl}
                  onChange={(e) => setAffiliateUrl(e.target.value)}
                  className="bg-slate-900/50 border-indigo-500/30 text-white placeholder:text-slate-500 focus:border-indigo-400"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="customName" className="text-indigo-100 flex items-center gap-2">
                  <Globe className="h-4 w-4 text-indigo-400" />
                  Nom du produit (optionnel)
                </Label>
                <Input
                  id="customName"
                  type="text"
                  placeholder="Nom personnalisé du produit"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="bg-slate-900/50 border-indigo-500/30 text-white placeholder:text-slate-500 focus:border-indigo-400"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="niche" className="text-indigo-100 flex items-center gap-2">
                  <Tag className="h-4 w-4 text-indigo-400" />
                  Niche (optionnel)
                </Label>
                <Input
                  id="niche"
                  type="text"
                  placeholder="Santé, Fitness, Technologie..."
                  value={niche}
                  onChange={(e) => setNiche(e.target.value)}
                  className="bg-slate-900/50 border-indigo-500/30 text-white placeholder:text-slate-500 focus:border-indigo-400"
                />
              </div>
            </div>

            {/* Template Selection */}
            <div className="space-y-3">
              <Label className="text-indigo-100 flex items-center gap-2">
                <Layout className="h-4 w-4 text-indigo-400" />
                Choisir un template
              </Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {TEMPLATES.map((template) => (
                  <button
                    key={template.id}
                    onClick={() => setSelectedTemplate(template.id)}
                    className={`p-4 rounded-xl border-2 transition-all text-left ${
                      selectedTemplate === template.id
                        ? 'border-indigo-500 bg-indigo-500/20 shadow-lg shadow-indigo-500/20'
                        : 'border-indigo-500/20 bg-slate-900/30 hover:border-indigo-400/50'
                    }`}
                  >
                    <span className="text-2xl">{template.icon}</span>
                    <p className="text-white font-medium mt-2">{template.name}</p>
                    <p className="text-xs text-indigo-300/60">{template.description}</p>
                  </button>
                ))}
              </div>
            </div>

            <Button 
              onClick={handleGenerate}
              disabled={isGenerating || !productUrl}
              className="w-full bg-gradient-to-r from-indigo-500 via-purple-500 to-violet-500 hover:from-indigo-600 hover:via-purple-600 hover:to-violet-600 text-white py-7 text-lg btn-glow transition-all"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Génération en cours...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  Générer mon site affilié
                  <ArrowRight className="ml-2 h-5 w-5" />
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Features */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          {[
            { icon: Zap, title: 'Ultra Rapide', desc: 'Génération en 60 secondes', color: 'indigo' },
            { icon: Sparkles, title: 'Optimisé IA', desc: 'Contenu persuasif', color: 'purple' },
            { icon: Palette, title: '4 Templates', desc: 'Designs professionnels', color: 'violet' },
            { icon: CheckCircle, title: 'Prêt à convertir', desc: 'Optimisé conversions', color: 'fuchsia' }
          ].map((feature, i) => (
            <Card key={i} className="glass-card hover:border-indigo-400/50 transition-all">
              <CardContent className="p-6 text-center">
                <div className={`w-12 h-12 rounded-full bg-${feature.color}-500/20 flex items-center justify-center mx-auto mb-4`}>
                  <feature.icon className={`h-6 w-6 text-${feature.color}-400`} />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-indigo-200/60 text-sm">{feature.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Sites List */}
        <div className="animate-fade-in" style={{ animationDelay: '0.4s' }}>
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-white">Mes sites générés</h3>
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="bg-indigo-500/20 text-indigo-300 border-indigo-500/30">
                {sites.length} site{sites.length !== 1 ? 's' : ''}
              </Badge>
              {userPlan === 'free' && (
                <Badge variant="outline" className="border-amber-500/50 text-amber-400">
                  {sitesCreated}/3 sites utilisés
                </Badge>
              )}
            </div>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-indigo-400" />
            </div>
          ) : sites.length === 0 ? (
            <Card className="glass-card border-dashed border-indigo-500/30">
              <CardContent className="py-16 text-center">
                <div className="w-16 h-16 rounded-full bg-indigo-500/20 flex items-center justify-center mx-auto mb-4">
                  <Globe className="h-8 w-8 text-indigo-400" />
                </div>
                <p className="text-indigo-200 text-lg">Aucun site généré pour le moment</p>
                <p className="text-indigo-300/50 text-sm mt-2">Créez votre premier site ci-dessus!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sites.map((site) => (
                <Card key={site.id} className="glass-card hover:border-indigo-400/50 transition-all group">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-white text-lg truncate">{site.name}</CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          {site.niche && (
                            <Badge variant="secondary" className="bg-indigo-500/20 text-indigo-300">
                              {site.niche}
                            </Badge>
                          )}
                          <Badge variant="outline" className="border-purple-500/30 text-purple-300">
                            {TEMPLATES.find(t => t.id === site.template)?.icon} {site.template}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-2">
                    <p className="text-indigo-200/60 text-sm mb-4 line-clamp-2">{site.headline}</p>
                    
                    {/* Image status */}
                    <div className="flex items-center gap-2 mb-4 text-xs">
                      {site.customImageUrl || site.imageUrl ? (
                        <Badge variant="outline" className="border-green-500/30 text-green-400">
                          <ImageIcon className="h-3 w-3 mr-1" />
                          Image OK
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="border-amber-500/30 text-amber-400">
                          <ImageIcon className="h-3 w-3 mr-1" />
                          Pas d&apos;image
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="default"
                        size="sm"
                        className="flex-1 bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
                        asChild
                      >
                        <a href={`/site/${site.slug}`} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-1" />
                          Voir
                        </a>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/20"
                        onClick={() => copyToClipboard(site.slug)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-purple-500/30 text-purple-300 hover:bg-purple-500/20"
                        onClick={() => setEditingImage(site.id)}
                      >
                        <ImageIcon className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-red-500/30 text-red-400 hover:bg-red-500/10"
                        onClick={() => handleDelete(site.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-indigo-300/40 mt-3">
                      Créé le {new Date(site.createdAt).toLocaleDateString('fr-FR')}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Pricing Modal */}
      {showPricing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <Card className="glass-card max-w-5xl w-full max-h-[90vh] overflow-y-auto">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-2xl text-white">Choisissez votre plan</CardTitle>
                <CardDescription className="text-indigo-200/60">
                  Débloquez tout le potentiel de AI Affiliate Builder
                </CardDescription>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setShowPricing(false)}>
                <X className="h-5 w-5 text-indigo-300" />
              </Button>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4">
                {PLANS.map((plan) => (
                  <Card 
                    key={plan.id}
                    className={`relative ${plan.popular ? 'border-indigo-500 bg-indigo-500/10' : 'border-indigo-500/20 bg-slate-900/30'}`}
                  >
                    {plan.popular && (
                      <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
                        <Star className="h-3 w-3 mr-1" />
                        Populaire
                      </Badge>
                    )}
                    <CardHeader className="text-center pb-2">
                      <CardTitle className="text-white">{plan.name}</CardTitle>
                      <div className="mt-4">
                        <span className="text-4xl font-bold text-white">{plan.price}€</span>
                        <span className="text-indigo-300/60">/mois</span>
                      </div>
                      <p className="text-sm text-indigo-300/40 mt-1">
                        ou {plan.priceYearly}€/an (économie 15%)
                      </p>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {plan.features.map((feature, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-indigo-400" />
                          <span className="text-indigo-100">{feature}</span>
                        </div>
                      ))}
                    </CardContent>
                    <CardFooter>
                      <Button 
                        className={`w-full ${plan.popular ? 'bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600' : 'bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300'}`}
                      >
                        <CreditCard className="h-4 w-4 mr-2" />
                        {plan.price === 0 ? 'Plan actuel' : 'Choisir'}
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-indigo-500/20 py-8 mt-12 relative">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-indigo-300/60">
            AI Affiliate Builder - Créez des sites affiliés optimisés en quelques secondes
          </p>
          <p className="text-indigo-300/40 text-sm mt-2">
            © 2024 AI Affiliate Builder. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  )
}
