import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const slug = searchParams.get('slug');
    
    if (slug) {
      const site = await db.affiliateSite.findUnique({
        where: { slug }
      });
      
      if (!site) {
        return NextResponse.json({ error: 'Site non trouvé' }, { status: 404 });
      }
      
      // Increment views
      await db.affiliateSite.update({
        where: { slug },
        data: { views: { increment: 1 } }
      });
      
      return NextResponse.json({ site });
    }
    
    // Get all sites
    const sites = await db.affiliateSite.findMany({
      orderBy: { createdAt: 'desc' },
      take: 50
    });
    
    return NextResponse.json({ sites });
  } catch (error) {
    console.error('Error fetching sites:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération des sites' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ error: 'ID requis' }, { status: 400 });
    }
    
    await db.affiliateSite.delete({
      where: { id }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting site:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la suppression' },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, template, customImageUrl, primaryColor, accentColor } = body;
    
    if (!id) {
      return NextResponse.json({ error: 'ID requis' }, { status: 400 });
    }
    
    const updateData: Record<string, string | undefined> = {};
    if (template) updateData.template = template;
    if (customImageUrl) updateData.customImageUrl = customImageUrl;
    if (primaryColor) updateData.primaryColor = primaryColor;
    if (accentColor) updateData.accentColor = accentColor;
    
    const site = await db.affiliateSite.update({
      where: { id },
      data: updateData
    });
    
    return NextResponse.json({ success: true, site });
  } catch (error) {
    console.error('Error updating site:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la mise à jour' },
      { status: 500 }
    );
  }
}
