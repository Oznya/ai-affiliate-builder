import { NextRequest, NextResponse } from 'next/server';

// This is a placeholder for Stripe integration
// In production, you would integrate with Stripe API

const PLANS = {
  free: { price: 0, sitesLimit: 3 },
  starter: { price: 19, sitesLimit: 10 },
  pro: { price: 49, sitesLimit: -1 },
  enterprise: { price: 199, sitesLimit: -1 }
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { plan, email, paymentMethodId } = body;
    
    if (!plan || !PLANS[plan as keyof typeof PLANS]) {
      return NextResponse.json({ error: 'Plan invalide' }, { status: 400 });
    }
    
    // In production, you would:
    // 1. Create a Stripe customer if not exists
    // 2. Attach payment method
    // 3. Create subscription
    // 4. Return client secret for confirmation
    
    const selectedPlan = PLANS[plan as keyof typeof PLANS];
    
    // Simulated response
    return NextResponse.json({
      success: true,
      message: 'Subscription created successfully',
      plan: {
        name: plan,
        price: selectedPlan.price,
        sitesLimit: selectedPlan.sitesLimit
      },
      // In production, return Stripe checkout URL or client secret
      checkoutUrl: plan !== 'free' ? `https://checkout.stripe.com/pay/test_${plan}` : null
    });
  } catch (error) {
    console.error('Error creating subscription:', error);
    return NextResponse.json({ error: 'Erreur lors de la souscription' }, { status: 500 });
  }
}

export async function GET() {
  // Return available plans
  return NextResponse.json({ plans: PLANS });
}
