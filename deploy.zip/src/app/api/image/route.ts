import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { generateProductImage } from '@/lib/ai-generator';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { siteId, productName, niche } = body;
    
    if (!siteId || !productName) {
      return NextResponse.json({ error: 'Site ID et nom du produit requis' }, { status: 400 });
    }
    
    // Generate new image
    const imageUrl = await generateProductImage(productName, niche || 'general');
    
    if (!imageUrl) {
      return NextResponse.json({ error: 'Impossible de générer l\'image' }, { status: 500 });
    }
    
    // Update site with new image
    await db.affiliateSite.update({
      where: { id: siteId },
      data: { imageUrl }
    });
    
    return NextResponse.json({ 
      success: true, 
      imageUrl 
    });
  } catch (error) {
    console.error('Error regenerating image:', error);
    return NextResponse.json({ error: 'Erreur lors de la génération' }, { status: 500 });
  }
}
