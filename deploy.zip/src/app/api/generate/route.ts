import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { 
  generateAffiliateContent, 
  generateProductImage, 
  generateSlug,
  fetchProductInfo 
} from '@/lib/ai-generator';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { productUrl, affiliateUrl, niche, customName, template } = body;

    if (!productUrl) {
      return NextResponse.json(
        { error: 'URL du produit requise' },
        { status: 400 }
      );
    }

    // Fetch product info from URL
    const productInfo = await fetchProductInfo(productUrl);
    const productName = customName || productInfo.name;

    // Generate AI content
    const content = await generateAffiliateContent(
      productName,
      productUrl,
      niche || 'general',
      productInfo.description || ''
    );

    // Generate product image
    let imageUrl: string | null = null;
    try {
      imageUrl = await generateProductImage(productName, niche || 'general');
    } catch (e) {
      console.log('Image generation skipped');
    }

    // Create slug
    const slug = generateSlug(productName);

    // Save to database
    const site = await db.affiliateSite.create({
      data: {
        name: productName,
        slug: slug,
        productName: productName,
        productUrl: productUrl,
        affiliateUrl: affiliateUrl || productUrl,
        niche: niche || null,
        headline: content.headline,
        subheadline: content.subheadline,
        description: content.description,
        features: JSON.stringify(content.features),
        benefits: JSON.stringify(content.benefits),
        pros: JSON.stringify(content.pros),
        cons: JSON.stringify(content.cons),
        faq: JSON.stringify(content.faq),
        callToAction: content.callToAction,
        imageUrl: imageUrl,
        template: template || 'modern',
        primaryColor: '#6366f1',
        accentColor: '#a855f7'
      }
    });

    return NextResponse.json({
      success: true,
      site: {
        id: site.id,
        slug: site.slug,
        name: site.name,
        headline: site.headline,
        subheadline: site.subheadline,
        template: site.template
      }
    });
  } catch (error) {
    console.error('Error generating site:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la génération du site' },
      { status: 500 }
    );
  }
}
