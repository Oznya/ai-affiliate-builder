import ZAI from 'z-ai-web-dev-sdk';

interface ProductInfo {
  name: string;
  url: string;
  description?: string;
}

interface GeneratedContent {
  headline: string;
  subheadline: string;
  description: string;
  features: string[];
  benefits: string[];
  pros: string[];
  cons: string[];
  faq: { question: string; answer: string }[];
  callToAction: string;
}

// Initialize ZAI
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

// Fetch product info from URL
export async function fetchProductInfo(url: string): Promise<ProductInfo> {
  try {
    const zai = await getZAI();
    
    // Use page reader to get product info
    const pageResult = await zai.functions.invoke('page_reader', {
      url: url
    });
    
    // Extract product name and description from the page
    const text = pageResult.data?.html?.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim() || '';
    const title = pageResult.data?.title || 'Produit';
    
    return {
      name: title.substring(0, 100),
      url: url,
      description: text.substring(0, 500)
    };
  } catch (error) {
    console.error('Error fetching product info:', error);
    return {
      name: 'Produit',
      url: url,
      description: ''
    };
  }
}

// Search for product information
export async function searchProductInfo(productName: string): Promise<string[]> {
  try {
    const zai = await getZAI();
    
    const searchResult = await zai.functions.invoke('web_search', {
      query: `${productName} review features benefits`,
      num: 5
    });
    
    return searchResult.map((r: { snippet: string }) => r.snippet).filter(Boolean);
  } catch (error) {
    console.error('Error searching product info:', error);
    return [];
  }
}

// Generate affiliate content using AI
export async function generateAffiliateContent(
  productName: string,
  productUrl: string,
  niche: string = 'general',
  additionalInfo: string = ''
): Promise<GeneratedContent> {
  const zai = await getZAI();
  
  // Search for additional product info
  const searchResults = await searchProductInfo(productName);
  const searchContext = searchResults.slice(0, 3).join('\n');
  
  const prompt = `Tu es un expert en marketing d'affiliation. Crée du contenu persuasif et optimisé pour la conversion pour ce produit.

PRODUIT: ${productName}
URL: ${productUrl}
NICHE: ${niche}
INFORMATIONS COMPLÉMENTAIRES: ${additionalInfo}

INFORMATIONS TROUVÉES EN LIGNE:
${searchContext}

Génère du contenu au format JSON avec la structure suivante:
{
  "headline": "Titre accrocheur principal (max 10 mots)",
  "subheadline": "Sous-titre persuasif (max 15 mots)",
  "description": "Description détaillée du produit (100-150 mots)",
  "features": ["Fonctionnalité 1", "Fonctionnalité 2", "Fonctionnalité 3", "Fonctionnalité 4", "Fonctionnalité 5"],
  "benefits": ["Bénéfice 1", "Bénéfice 2", "Bénéfice 3", "Bénéfice 4"],
  "pros": ["Point positif 1", "Point positif 2", "Point positif 3"],
  "cons": ["Point négatif 1", "Point négatif 2"],
  "faq": [
    {"question": "Question 1?", "answer": "Réponse 1"},
    {"question": "Question 2?", "answer": "Réponse 2"},
    {"question": "Question 3?", "answer": "Réponse 3"}
  ],
  "callToAction": "Texte d'appel à l'action persuasif (max 10 mots)"
}

RÈGLES:
- Utilise un ton enthousiaste mais professionnel
- Les bénéfices doivent être des résultats concrets pour l'utilisateur
- Les features sont des caractéristiques du produit
- Les pros/cons doivent être honnêtes mais équilibrés
- Le callToAction doit créer un sentiment d'urgence
- Réponds UNIQUEMENT avec le JSON, sans texte additionnel`;

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'Tu es un expert en copywriting et marketing d\'affiliation. Tu génères du contenu optimisé pour la conversion.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.8,
      max_tokens: 2000
    });

    const responseText = completion.choices[0]?.message?.content || '';
    
    // Extract JSON from response
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    
    throw new Error('No valid JSON in response');
  } catch (error) {
    console.error('Error generating content:', error);
    
    // Return default content if AI fails
    return {
      headline: `Découvrez ${productName}`,
      subheadline: 'La solution parfaite pour vos besoins',
      description: `${productName} est un produit de qualité supérieure conçu pour répondre à vos besoins. Avec ses caractéristiques innovantes et son excellent rapport qualité-prix, il représente le meilleur choix dans sa catégorie.`,
      features: [
        'Qualité supérieure',
        'Facile à utiliser',
        'Excellent rapport qualité-prix',
        'Support client réactif',
        'Garantie satisfaction'
      ],
      benefits: [
        'Gagnez du temps au quotidien',
        'Résultats visibles rapidement',
        'Investissement rentabilisé'
      ],
      pros: ['Produit de qualité', 'Bon prix', 'Livraison rapide'],
      cons: ['Demande un apprentissage initial'],
      faq: [
        { question: 'Est-ce facile à utiliser?', answer: 'Oui, le produit est conçu pour être intuitif et facile à prendre en main.' },
        { question: 'Y a-t-il une garantie?', answer: 'Oui, le produit bénéficie d\'une garantie satisfaction.' }
      ],
      callToAction: 'Obtenez le vôtre maintenant!'
    };
  }
}

// Generate product image
export async function generateProductImage(productName: string, niche: string): Promise<string | null> {
  try {
    const zai = await getZAI();
    
    const response = await zai.images.generations.create({
      prompt: `Professional product photography of ${productName}, ${niche} product, clean white background, studio lighting, high quality, commercial photography`,
      size: '1024x1024'
    });
    
    return response.data[0]?.base64 || null;
  } catch (error) {
    console.error('Error generating image:', error);
    return null;
  }
}

// Generate unique slug
export function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .substring(0, 50) + '-' + Math.random().toString(36).substring(2, 8);
}
