var a={},b=(f,m,h)=>(a.__chunk_7015=(g,o,s)=>{"use strict";async function u(e,i){let t=await fetch("https://api.groq.com/openai/v1/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${process.env.GROQ_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({model:"llama-3.3-70b-versatile",messages:[{role:"system",content:i},{role:"user",content:e}],temperature:.8,max_tokens:2e3})});if(!t.ok)throw Error(`Groq API error: ${t.status}`);return(await t.json()).choices[0]?.message?.content||""}async function c(e,i,t="general",r=""){let x=`Tu es un expert en marketing d'affiliation. Cr\xE9e du contenu persuasif pour ce produit.

PRODUIT: ${e}
URL: ${i}
NICHE: ${t}
INFO: ${r}

R\xE9ponds UNIQUEMENT avec du JSON valide:
{
  "headline": "Titre accrocheur (max 10 mots)",
  "subheadline": "Sous-titre persuasif (max 15 mots)",
  "description": "Description d\xE9taill\xE9e (100-150 mots)",
  "features": ["Feature 1", "Feature 2", "Feature 3", "Feature 4", "Feature 5"],
  "benefits": ["B\xE9n\xE9fice 1", "B\xE9n\xE9fice 2", "B\xE9n\xE9fice 3"],
  "pros": ["Point positif 1", "Point positif 2", "Point positif 3"],
  "cons": ["Point n\xE9gatif 1", "Point n\xE9gatif 2"],
  "faq": [{"question": "Question 1?", "answer": "R\xE9ponse 1"}, {"question": "Question 2?", "answer": "R\xE9ponse 2"}],
  "callToAction": "Appel \xE0 l'action (max 10 mots)"
}`;try{let n=(await u(x,"Tu es un expert en copywriting. R\xE9ponds uniquement avec du JSON valide.")).match(/\{[\s\S]*\}/);if(n)return JSON.parse(n[0])}catch(n){console.error("AI generation error:",n)}return{headline:`D\xE9couvrez ${e}`,subheadline:"La solution parfaite pour vos besoins",description:`${e} est un produit de qualit\xE9 sup\xE9rieure con\xE7u pour r\xE9pondre \xE0 vos besoins.`,features:["Qualit\xE9 sup\xE9rieure","Facile \xE0 utiliser","Excellent rapport qualit\xE9-prix","Support r\xE9actif","Garantie"],benefits:["Gagnez du temps","R\xE9sultats rapides","Investissement rentable"],pros:["Produit de qualit\xE9","Bon prix","Livraison rapide"],cons:["Apprentissage initial requis"],faq:[{question:"Est-ce facile?",answer:"Oui, tr\xE8s intuitif."}],callToAction:"Commandez maintenant!"}}async function l(e,i){try{let t=await fetch("https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image",{method:"POST",headers:{Authorization:`Bearer ${process.env.STABILITY_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({text_prompts:[{text:`Professional product photography of ${e}, ${i}, clean background, studio lighting`}],cfg_scale:7,height:1024,width:1024,steps:30,samples:1})});return t.ok&&(await t.json()).data[0]?.b64_json||null}catch{return null}}async function p(e){try{let i=await fetch(e,{headers:{"User-Agent":"Mozilla/5.0 (compatible; AffiliateBot/1.0)"}}),t=(await i.text()).match(/<title[^>]*>([^<]+)<\/title>/i);return{name:t?t[1].split("|")[0].trim():"Produit",description:""}}catch{return{name:"Produit",description:""}}}function d(e){return e.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").substring(0,50)+"-"+Math.random().toString(36).substring(2,8)}s.d(o,{Gd:()=>l,c_:()=>p,gS:()=>c,z9:()=>d})},a);export{b as __getNamedExports};
